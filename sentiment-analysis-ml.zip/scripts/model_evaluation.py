import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
from sklearn.preprocessing import label_binarize
import pickle
import os

class ModelEvaluator:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.label_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
        self.reverse_mapping = {0: 'negative', 1: 'neutral', 2: 'positive'}
        
    def load_model_and_vectorizer(self):
        """Load the trained model and vectorizer"""
        # Load model
        with open('models/sentiment_model.pkl', 'rb') as f:
            self.model = pickle.load(f)
        
        # Load vectorizer
        with open('models/tfidf_vectorizer.pkl', 'rb') as f:
            self.vectorizer = pickle.load(f)
        
        print("Model and vectorizer loaded successfully")
    
    def comprehensive_evaluation(self, test_data_path='data/processed_reviews.csv'):
        """Perform comprehensive model evaluation"""
        print("Starting comprehensive model evaluation...")
        
        # Load test data
        df = pd.read_csv(test_data_path)
        
        # Prepare test data (using last 20% as test set)
        test_size = int(len(df) * 0.2)
        test_df = df.tail(test_size)
        
        # Transform text data
        X_test = self.vectorizer.transform(test_df['processed_text'])
        y_test = test_df['sentiment'].map(self.label_mapping)
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)
        
        # Calculate metrics
        metrics = self.calculate_metrics(y_test, y_pred)
        
        # Generate visualizations
        self.create_visualizations(y_test, y_pred, y_pred_proba)
        
        # Analyze misclassifications
        self.analyze_misclassifications(test_df, y_test, y_pred)
        
        # Feature importance analysis
        self.analyze_feature_importance()
        
        return metrics
    
    def calculate_metrics(self, y_true, y_pred):
        """Calculate various evaluation metrics"""
        metrics = {}
        
        # Basic metrics
        metrics['accuracy'] = accuracy_score(y_true, y_pred)
        metrics['precision_macro'] = precision_score(y_true, y_pred, average='macro')
        metrics['recall_macro'] = recall_score(y_true, y_pred, average='macro')
        metrics['f1_macro'] = f1_score(y_true, y_pred, average='macro')
        
        # Per-class metrics
        precision_per_class = precision_score(y_true, y_pred, average=None)
        recall_per_class = recall_score(y_true, y_pred, average=None)
        f1_per_class = f1_score(y_true, y_pred, average=None)
        
        for i, sentiment in enumerate(['negative', 'neutral', 'positive']):
            metrics[f'precision_{sentiment}'] = precision_per_class[i]
            metrics[f'recall_{sentiment}'] = recall_per_class[i]
            metrics[f'f1_{sentiment}'] = f1_per_class[i]
        
        # Print metrics
        print("\n" + "="*50)
        print("MODEL EVALUATION METRICS")
        print("="*50)
        print(f"Overall Accuracy: {metrics['accuracy']:.4f}")
        print(f"Macro Precision: {metrics['precision_macro']:.4f}")
        print(f"Macro Recall: {metrics['recall_macro']:.4f}")
        print(f"Macro F1-Score: {metrics['f1_macro']:.4f}")
        
        print("\nPer-Class Metrics:")
        for sentiment in ['negative', 'neutral', 'positive']:
            print(f"{sentiment.capitalize()}:")
            print(f"  Precision: {metrics[f'precision_{sentiment}']:.4f}")
            print(f"  Recall: {metrics[f'recall_{sentiment}']:.4f}")
            print(f"  F1-Score: {metrics[f'f1_{sentiment}']:.4f}")
        
        return metrics
    
    def create_visualizations(self, y_true, y_pred, y_pred_proba):
        """Create various visualization plots"""
        print("Creating evaluation visualizations...")
        
        # Set up the plotting style
        plt.style.use('default')
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. Confusion Matrix
        cm = confusion_matrix(y_true, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=['Negative', 'Neutral', 'Positive'],
                   yticklabels=['Negative', 'Neutral', 'Positive'],
                   ax=axes[0, 0])
        axes[0, 0].set_title('Confusion Matrix')
        axes[0, 0].set_ylabel('True Label')
        axes[0, 0].set_xlabel('Predicted Label')
        
        # 2. Class Distribution
        unique, counts = np.unique(y_true, return_counts=True)
        class_names = ['Negative', 'Neutral', 'Positive']
        axes[0, 1].bar(class_names, counts, color=['red', 'gray', 'green'], alpha=0.7)
        axes[0, 1].set_title('True Class Distribution')
        axes[0, 1].set_ylabel('Count')
        
        # 3. Prediction Confidence Distribution
        max_proba = np.max(y_pred_proba, axis=1)
        axes[1, 0].hist(max_proba, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
        axes[1, 0].set_title('Prediction Confidence Distribution')
        axes[1, 0].set_xlabel('Max Probability')
        axes[1, 0].set_ylabel('Frequency')
        
        # 4. Per-class F1 Scores
        f1_scores = [
            f1_score(y_true, y_pred, labels=[i], average='macro') 
            for i in range(3)
        ]
        axes[1, 1].bar(class_names, f1_scores, color=['red', 'gray', 'green'], alpha=0.7)
        axes[1, 1].set_title('F1-Score by Class')
        axes[1, 1].set_ylabel('F1-Score')
        axes[1, 1].set_ylim(0, 1)
        
        plt.tight_layout()
        plt.savefig('models/evaluation_plots.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    def analyze_misclassifications(self, test_df, y_true, y_pred):
        """Analyze misclassified examples"""
        print("Analyzing misclassifications...")
        
        # Find misclassified examples
        misclassified_mask = y_true != y_pred
        misclassified_df = test_df[misclassified_mask].copy()
        misclassified_df['true_label'] = y_true[misclassified_mask]
        misclassified_df['predicted_label'] = y_pred[misclassified_mask]
        
        print(f"\nTotal misclassifications: {len(misclassified_df)}")
        
        # Show some examples
        print("\nSample Misclassifications:")
        print("-" * 80)
        
        for i, row in misclassified_df.head(5).iterrows():
            true_sentiment = self.reverse_mapping[row['true_label']]
            pred_sentiment = self.reverse_mapping[row['predicted_label']]
            
            print(f"Review: {row['review'][:100]}...")
            print(f"True: {true_sentiment} | Predicted: {pred_sentiment}")
            print("-" * 80)
        
        # Save misclassifications
        misclassified_df.to_csv('models/misclassifications.csv', index=False)
        print("Misclassifications saved to models/misclassifications.csv")
    
    def analyze_feature_importance(self):
        """Analyze most important features (words) for each class"""
        print("Analyzing feature importance...")
        
        # Get feature names
        feature_names = self.vectorizer.get_feature_names_out()
        
        # Get class probabilities for each feature
        feature_log_prob = self.model.feature_log_prob_
        
        # Find top features for each class
        top_features = {}
        n_top = 20
        
        for i, class_name in enumerate(['negative', 'neutral', 'positive']):
            top_indices = np.argsort(feature_log_prob[i])[-n_top:][::-1]
            top_features[class_name] = [
                (feature_names[idx], feature_log_prob[i][idx]) 
                for idx in top_indices
            ]
        
        # Create visualization
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        
        for i, (class_name, features) in enumerate(top_features.items()):
            words = [f[0] for f in features]
            scores = [f[1] for f in features]
            
            axes[i].barh(range(len(words)), scores, color=['red', 'gray', 'green'][i], alpha=0.7)
            axes[i].set_yticks(range(len(words)))
            axes[i].set_yticklabels(words)
            axes[i].set_title(f'Top Features for {class_name.capitalize()}')
            axes[i].set_xlabel('Log Probability')
        
        plt.tight_layout()
        plt.savefig('models/feature_importance.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        # Save feature importance
        with open('models/feature_importance.txt', 'w') as f:
            for class_name, features in top_features.items():
                f.write(f"\nTop features for {class_name}:\n")
                for word, score in features:
                    f.write(f"{word}: {score:.4f}\n")
        
        print("Feature importance analysis saved to models/feature_importance.txt")

def run_evaluation():
    """Run comprehensive model evaluation"""
    evaluator = ModelEvaluator()
    evaluator.load_model_and_vectorizer()
    metrics = evaluator.comprehensive_evaluation()
    
    print("\nEvaluation completed successfully!")
    print("Results saved in 'models' directory")
    
    return metrics

if __name__ == "__main__":
    # Run evaluation
    metrics = run_evaluation()
