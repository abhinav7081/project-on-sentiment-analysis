import pandas as pd
import numpy as np
import nltk
import re
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
import pickle
import os

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class TextPreprocessor:
    def __init__(self):
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        self.vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
        
    def clean_text(self, text):
        """Clean and preprocess text data"""
        if pd.isna(text):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove HTML tags
        text = re.sub(r'<.*?>', '', text)
        
        # Remove special characters and digits
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def tokenize_and_stem(self, text):
        """Tokenize text and apply stemming"""
        if not text:
            return ""
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords and apply stemming
        processed_tokens = [
            self.stemmer.stem(token) 
            for token in tokens 
            if token not in self.stop_words and len(token) > 2
        ]
        
        return ' '.join(processed_tokens)
    
    def preprocess_data(self, df, text_column='review', target_column='sentiment'):
        """Complete preprocessing pipeline"""
        print("Starting data preprocessing...")
        
        # Create a copy of the dataframe
        processed_df = df.copy()
        
        # Clean text
        print("Cleaning text...")
        processed_df['cleaned_text'] = processed_df[text_column].apply(self.clean_text)
        
        # Tokenize and stem
        print("Tokenizing and stemming...")
        processed_df['processed_text'] = processed_df['cleaned_text'].apply(self.tokenize_and_stem)
        
        # Remove empty reviews
        processed_df = processed_df[processed_df['processed_text'].str.len() > 0]
        
        print(f"Preprocessing complete. {len(processed_df)} reviews remaining.")
        return processed_df
    
    def fit_vectorizer(self, texts):
        """Fit TF-IDF vectorizer on training data"""
        print("Fitting TF-IDF vectorizer...")
        self.vectorizer.fit(texts)
        
        # Save vectorizer
        os.makedirs('models', exist_ok=True)
        with open('models/tfidf_vectorizer.pkl', 'wb') as f:
            pickle.dump(self.vectorizer, f)
        
        print("Vectorizer saved to models/tfidf_vectorizer.pkl")
    
    def transform_texts(self, texts):
        """Transform texts using fitted vectorizer"""
        return self.vectorizer.transform(texts)

def load_and_preprocess_data(file_path):
    """Load and preprocess the dataset"""
    print(f"Loading data from {file_path}...")
    
    # Load data
    df = pd.read_csv(file_path)
    print(f"Loaded {len(df)} reviews")
    
    # Display basic info
    print("\nDataset Info:")
    print(df.info())
    print("\nSentiment Distribution:")
    print(df['sentiment'].value_counts())
    
    # Initialize preprocessor
    preprocessor = TextPreprocessor()
    
    # Preprocess data
    processed_df = preprocessor.preprocess_data(df)
    
    # Fit vectorizer on all processed texts
    preprocessor.fit_vectorizer(processed_df['processed_text'])
    
    # Save processed data
    processed_df.to_csv('data/processed_reviews.csv', index=False)
    print("Processed data saved to data/processed_reviews.csv")
    
    return processed_df, preprocessor

if __name__ == "__main__":
    # Create data directory
    os.makedirs('data', exist_ok=True)
    
    # Load and preprocess data
    df, preprocessor = load_and_preprocess_data('sample_reviews.csv')
    
    print("\nPreprocessing completed successfully!")
    print(f"Sample processed review:")
    print(f"Original: {df.iloc[0]['review'][:100]}...")
    print(f"Processed: {df.iloc[0]['processed_text'][:100]}...")
