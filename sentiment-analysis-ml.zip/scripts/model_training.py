import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
import pickle
import os
import matplotlib.pyplot as plt
import seaborn as sns

class SentimentClassifier:
    def __init__(self):
        self.model = MultinomialNB(alpha=1.0)
        self.vectorizer = None
        self.label_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
        self.reverse_mapping = {0: 'negative', 1: 'neutral', 2: 'positive'}
        
    def load_vectorizer(self, vectorizer_path='models/tfidf_vectorizer.pkl'):
        """Load the fitted TF-IDF vectorizer"""
        with open(vectorizer_path, 'rb') as f:
            self.vectorizer = pickle.load(f)
        print("Vectorizer loaded successfully")
    
    def prepare_data(self, df, text_column='processed_text', target_column='sentiment'):
        """Prepare data for training"""
        print("Preparing data for training...")
        
        # Convert text to TF-IDF features
        X = self.vectorizer.transform(df[text_column])
        
        # Convert sentiment labels to numeric
        y = df[target_column].map(self.label_mapping)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        print(f"Training set size: {X_train.shape[0]}")
        print(f"Test set size: {X_test.shape[0]}")
        
        return X_train, X_test, y_train, y_test
    
    def train_model(self, X_train, y_train):
        """Train the Naive Bayes classifier"""
        print("Training Naive Bayes classifier...")
        
        self.model.fit(X_train, y_train)
        
        # Save the trained model
        os.makedirs('models', exist_ok=True)
        with open('models/sentiment_model.pkl', 'wb') as f:
            pickle.dump(self.model, f)
        
        print("Model trained and saved to models/sentiment_model.pkl")
    
    def evaluate_model(self, X_test, y_test):
        """Evaluate the trained model"""
        print("Evaluating model...")
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        
        print(f"\nModel Performance:")
        print(f"Accuracy: {accuracy:.4f}")
        
        # Detailed classification report
        target_names = ['Negative', 'Neutral', 'Positive']
        report = classification_report(y_test, y_pred, target_names=target_names)
        print(f"\nClassification Report:")
        print(report)
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        
        # Plot confusion matrix
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=target_names, yticklabels=target_names)
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig('models/confusion_matrix.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return accuracy, report, cm
    
    def predict_sentiment(self, text):
        """Predict sentiment for a single text"""
        if self.vectorizer is None or self.model is None:
            raise ValueError("Model and vectorizer must be loaded first")
        
        # Transform text
        text_vector = self.vectorizer.transform([text])
        
        # Predict
        prediction = self.model.predict(text_vector)[0]
        probability = self.model.predict_proba(text_vector)[0]
        
        sentiment = self.reverse_mapping[prediction]
        confidence = max(probability)
        
        return sentiment, confidence

def train_sentiment_model():
    """Main function to train the sentiment analysis model"""
    
    # Load processed data
    print("Loading processed data...")
    df = pd.read_csv('data/processed_reviews.csv')
    
    # Initialize classifier
    classifier = SentimentClassifier()
    
    # Load vectorizer
    classifier.load_vectorizer()
    
    # Prepare data
    X_train, X_test, y_train, y_test = classifier.prepare_data(df)
    
    # Train model
    classifier.train_model(X_train, y_train)
    
    # Evaluate model
    accuracy, report, cm = classifier.evaluate_model(X_test, y_test)
    
    # Save evaluation results
    with open('models/evaluation_report.txt', 'w') as f:
        f.write(f"Model Accuracy: {accuracy:.4f}\n\n")
        f.write("Classification Report:\n")
        f.write(report)
    
    print("\nTraining completed successfully!")
    print("Model and evaluation results saved in 'models' directory")
    
    return classifier

if __name__ == "__main__":
    # Create models directory
    os.makedirs('models', exist_ok=True)
    
    # Train the model
    classifier = train_sentiment_model()
    
    # Test with sample predictions
    print("\nTesting model with sample texts:")
    
    sample_texts = [
        "This product is amazing! I love it so much.",
        "The quality is terrible. Waste of money.",
        "It's okay, nothing special but does the job."
    ]
    
    for text in sample_texts:
        sentiment, confidence = classifier.predict_sentiment(text)
        print(f"Text: '{text}'")
        print(f"Predicted Sentiment: {sentiment} (Confidence: {confidence:.3f})")
        print("-" * 50)
