import streamlit as st
import pandas as pd
import numpy as np
import pickle
import plotly.express as px
import plotly.graph_objects as go
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import re
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
import nltk

# Download NLTK data if not already present
@st.cache_resource
def download_nltk_data():
    try:
        nltk.data.find('tokenizers/punkt')
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('punkt')
        nltk.download('stopwords')

class SentimentAnalyzer:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        self.load_model()
    
    @st.cache_resource
    def load_model(_self):
        """Load the trained model and vectorizer"""
        try:
            with open('models/sentiment_model.pkl', 'rb') as f:
                _self.model = pickle.load(f)
            
            with open('models/tfidf_vectorizer.pkl', 'rb') as f:
                _self.vectorizer = pickle.load(f)
            
            return True
        except FileNotFoundError:
            return False
    
    def preprocess_text(self, text):
        """Preprocess text for prediction"""
        if pd.isna(text):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove HTML tags
        text = re.sub(r'<.*?>', '', text)
        
        # Remove special characters and digits
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords and apply stemming
        processed_tokens = [
            self.stemmer.stem(token) 
            for token in tokens 
            if token not in self.stop_words and len(token) > 2
        ]
        
        return ' '.join(processed_tokens)
    
    def predict_sentiment(self, text):
        """Predict sentiment for given text"""
        if not self.model or not self.vectorizer:
            return None, None, None
        
        # Preprocess text
        processed_text = self.preprocess_text(text)
        
        if not processed_text:
            return "neutral", 0.33, [0.33, 0.34, 0.33]
        
        # Transform text
        text_vector = self.vectorizer.transform([processed_text])
        
        # Predict
        prediction = self.model.predict(text_vector)[0]
        probabilities = self.model.predict_proba(text_vector)[0]
        
        sentiment_map = {0: 'negative', 1: 'neutral', 2: 'positive'}
        sentiment = sentiment_map[prediction]
        confidence = max(probabilities)
        
        return sentiment, confidence, probabilities

def main():
    st.set_page_config(
        page_title="Sentiment Analysis App",
        page_icon="😊",
        layout="wide"
    )
    
    # Download NLTK data
    download_nltk_data()
    
    # Initialize analyzer
    analyzer = SentimentAnalyzer()
    
    # Header
    st.title("🎭 Product Review Sentiment Analysis")
    st.markdown("---")
    
    # Sidebar
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose a page",
        ["Single Review Analysis", "Batch Analysis", "Model Information", "Sample Data"]
    )
    
    if page == "Single Review Analysis":
        single_review_analysis(analyzer)
    elif page == "Batch Analysis":
        batch_analysis(analyzer)
    elif page == "Model Information":
        model_information()
    else:
        sample_data_page()

def single_review_analysis(analyzer):
    st.header("📝 Single Review Analysis")
    
    # Check if model is loaded
    if not analyzer.model:
        st.error("❌ Model not found! Please run the training scripts first.")
        st.info("Run the following scripts in order:")
        st.code("python scripts/data_preprocessing.py")
        st.code("python scripts/model_training.py")
        return
    
    # Text input
    review_text = st.text_area(
        "Enter a product review:",
        placeholder="Type your review here...",
        height=150
    )
    
    if st.button("Analyze Sentiment", type="primary"):
        if review_text.strip():
            # Predict sentiment
            sentiment, confidence, probabilities = analyzer.predict_sentiment(review_text)
            
            # Display results
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.subheader("Prediction Results")
                
                # Sentiment with emoji
                emoji_map = {
                    'positive': '😊',
                    'negative': '😞',
                    'neutral': '😐'
                }
                
                st.markdown(f"### {emoji_map[sentiment]} **{sentiment.upper()}**")
                st.markdown(f"**Confidence:** {confidence:.2%}")
                
                # Confidence bar
                st.progress(confidence)
            
            with col2:
                st.subheader("Probability Distribution")
                
                # Create probability chart
                labels = ['Negative', 'Neutral', 'Positive']
                colors = ['#ff6b6b', '#ffd93d', '#6bcf7f']
                
                fig = go.Figure(data=[
                    go.Bar(
                        x=labels,
                        y=probabilities,
                        marker_color=colors,
                        text=[f'{p:.2%}' for p in probabilities],
                        textposition='auto'
                    )
                ])
                
                fig.update_layout(
                    title="Sentiment Probabilities",
                    yaxis_title="Probability",
                    showlegend=False,
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Please enter a review to analyze.")

def batch_analysis(analyzer):
    st.header("📊 Batch Analysis")
    
    if not analyzer.model:
        st.error("❌ Model not found! Please run the training scripts first.")
        return
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload a CSV file with reviews",
        type=['csv'],
        help="CSV should have a 'review' column"
    )
    
    if uploaded_file is not None:
        try:
            # Load data
            df = pd.read_csv(uploaded_file)
            
            if 'review' not in df.columns:
                st.error("CSV file must contain a 'review' column")
                return
            
            st.success(f"Loaded {len(df)} reviews")
            
            # Show sample data
            st.subheader("Sample Data")
            st.dataframe(df.head())
            
            if st.button("Analyze All Reviews", type="primary"):
                # Progress bar
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                # Analyze reviews
                results = []
                for i, review in enumerate(df['review']):
                    sentiment, confidence, probabilities = analyzer.predict_sentiment(str(review))
                    results.append({
                        'sentiment': sentiment,
                        'confidence': confidence,
                        'neg_prob': probabilities[0],
                        'neu_prob': probabilities[1],
                        'pos_prob': probabilities[2]
                    })
                    
                    # Update progress
                    progress = (i + 1) / len(df)
                    progress_bar.progress(progress)
                    status_text.text(f'Analyzing review {i + 1} of {len(df)}')
                
                # Add results to dataframe
                results_df = pd.DataFrame(results)
                final_df = pd.concat([df, results_df], axis=1)
                
                # Clear progress indicators
                progress_bar.empty()
                status_text.empty()
                
                # Display results
                st.subheader("Analysis Results")
                st.dataframe(final_df)
                
                # Summary statistics
                col1, col2, col3 = st.columns(3)
                
                sentiment_counts = final_df['sentiment'].value_counts()
                
                with col1:
                    st.metric("Positive Reviews", sentiment_counts.get('positive', 0))
                
                with col2:
                    st.metric("Neutral Reviews", sentiment_counts.get('neutral', 0))
                
                with col3:
                    st.metric("Negative Reviews", sentiment_counts.get('negative', 0))
                
                # Visualization
                fig = px.pie(
                    values=sentiment_counts.values,
                    names=sentiment_counts.index,
                    title="Sentiment Distribution",
                    color_discrete_map={
                        'positive': '#6bcf7f',
                        'neutral': '#ffd93d',
                        'negative': '#ff6b6b'
                    }
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Download results
                csv = final_df.to_csv(index=False)
                st.download_button(
                    label="Download Results as CSV",
                    data=csv,
                    file_name="sentiment_analysis_results.csv",
                    mime="text/csv"
                )
                
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def model_information():
    st.header("🤖 Model Information")
    
    st.markdown("""
    ## About the Sentiment Analysis Model
    
    This sentiment analysis system uses a **Naive Bayes classifier** trained on product reviews to classify text into three categories:
    - 😊 **Positive**: Reviews expressing satisfaction or praise
    - 😐 **Neutral**: Reviews with balanced or factual content
    - 😞 **Negative**: Reviews expressing dissatisfaction or criticism
    
    ### Model Architecture
    - **Algorithm**: Multinomial Naive Bayes
    - **Feature Extraction**: TF-IDF (Term Frequency-Inverse Document Frequency)
    - **Text Preprocessing**: Tokenization, Stopword Removal, Stemming
    - **Feature Limit**: 5000 most important features
    - **N-grams**: Unigrams and Bigrams
    
    ### Preprocessing Pipeline
    1. **Text Cleaning**: Remove HTML tags, special characters, and extra whitespace
    2. **Tokenization**: Split text into individual words
    3. **Stopword Removal**: Remove common words like 'the', 'and', 'is'
    4. **Stemming**: Reduce words to their root form (e.g., 'running' → 'run')
    5. **TF-IDF Vectorization**: Convert text to numerical features
    
    ### Model Performance
    The model achieves good performance across all sentiment classes with balanced precision and recall scores.
    """)
    
    # Try to load and display evaluation metrics
    try:
        with open('models/evaluation_report.txt', 'r') as f:
            report = f.read()
        
        st.subheader("📈 Model Performance Metrics")
        st.text(report)
        
    except FileNotFoundError:
        st.info("Run model evaluation script to see detailed performance metrics.")
    
    # Display confusion matrix if available
    try:
        st.subheader("📊 Confusion Matrix")
        st.image('models/confusion_matrix.png')
    except FileNotFoundError:
        st.info("Confusion matrix will appear here after model training.")

def sample_data_page():
    st.header("📋 Sample Data")
    
    st.markdown("""
    ## Sample Product Reviews Dataset
    
    Here's a preview of the sample dataset used for training the sentiment analysis model.
    The dataset contains product reviews with their corresponding sentiment labels.
    """)
    
    # Try to load sample data
    try:
        df = pd.read_csv('sample_reviews.csv')
        
        st.subheader("Dataset Overview")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Reviews", len(df))
        
        with col2:
            st.metric("Unique Products", df['product'].nunique() if 'product' in df.columns else 'N/A')
        
        with col3:
            avg_length = df['review'].str.len().mean()
            st.metric("Avg Review Length", f"{avg_length:.0f} chars")
        
        # Sentiment distribution
        if 'sentiment' in df.columns:
            st.subheader("Sentiment Distribution")
            sentiment_counts = df['sentiment'].value_counts()
            
            fig = px.bar(
                x=sentiment_counts.index,
                y=sentiment_counts.values,
                color=sentiment_counts.index,
                color_discrete_map={
                    'positive': '#6bcf7f',
                    'neutral': '#ffd93d',
                    'negative': '#ff6b6b'
                },
                title="Number of Reviews by Sentiment"
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        # Sample reviews
        st.subheader("Sample Reviews")
        st.dataframe(df.head(10))
        
        # Download sample data
        csv = df.to_csv(index=False)
        st.download_button(
            label="Download Sample Dataset",
            data=csv,
            file_name="sample_reviews.csv",
            mime="text/csv"
        )
        
    except FileNotFoundError:
        st.error("Sample dataset not found. Please ensure 'sample_reviews.csv' exists in the project directory.")

if __name__ == "__main__":
    main()
