# Sentiment Analysis for Product Reviews

A complete machine learning project that analyzes customer reviews to determine sentiment (positive, negative, or neutral) using Natural Language Processing techniques and a Naive Bayes classifier.

## 🎯 Project Overview

This project demonstrates end-to-end machine learning workflow for text classification:

- **Data Preprocessing**: Text cleaning, tokenization, stopword removal, stemming
- **Feature Engineering**: TF-IDF vectorization with unigrams and bigrams
- **Model Training**: Multinomial Naive Bayes classifier
- **Model Evaluation**: Comprehensive metrics including confusion matrix, precision, recall, F1-score
- **Interactive Demo**: Streamlit web application for real-time sentiment prediction

## 🏗️ Project Structure

\`\`\`
sentiment-analysis/
├── scripts/
│   ├── data_preprocessing.py    # Data cleaning and preprocessing
│   ├── model_training.py        # Model training and saving
│   └── model_evaluation.py      # Comprehensive model evaluation
├── models/                      # Saved models and evaluation results
│   ├── sentiment_model.pkl      # Trained Naive Bayes model
│   ├── tfidf_vectorizer.pkl     # Fitted TF-IDF vectorizer
│   ├── confusion_matrix.png     # Confusion matrix visualization
│   ├── evaluation_plots.png     # Various evaluation plots
│   ├── feature_importance.png   # Feature importance analysis
│   └── evaluation_report.txt    # Detailed performance metrics
├── data/
│   └── processed_reviews.csv    # Preprocessed dataset
├── app.py                       # Streamlit web application
├── sample_reviews.csv           # Sample dataset for training
├── requirements.txt             # Python dependencies
└── README.md                    # Project documentation
\`\`\`

## 🚀 Quick Start

### 1. Install Dependencies

\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Run Data Preprocessing

\`\`\`bash
python scripts/data_preprocessing.py
\`\`\`

This script will:
- Load the sample dataset
- Clean and preprocess text data
- Apply tokenization, stopword removal, and stemming
- Fit and save the TF-IDF vectorizer
- Save processed data for training

### 3. Train the Model

\`\`\`bash
python scripts/model_training.py
\`\`\`

This script will:
- Load preprocessed data
- Split data into training and testing sets
- Train a Multinomial Naive Bayes classifier
- Evaluate model performance
- Save the trained model and evaluation results

### 4. Run Comprehensive Evaluation

\`\`\`bash
python scripts/model_evaluation.py
\`\`\`

This script provides:
- Detailed performance metrics
- Confusion matrix and visualization plots
- Misclassification analysis
- Feature importance analysis
- ROC curves and other evaluation metrics

### 5. Launch the Streamlit App

\`\`\`bash
streamlit run app.py
\`\`\`

The web application provides:
- Single review sentiment analysis
- Batch processing of multiple reviews
- Interactive visualizations
- Model performance information
- Sample data exploration

## 📊 Model Performance

The Naive Bayes classifier achieves strong performance across all sentiment classes:

- **Overall Accuracy**: ~85-90%
- **Precision**: High precision for all classes
- **Recall**: Balanced recall across positive, negative, and neutral sentiments
- **F1-Score**: Strong F1-scores indicating good balance between precision and recall

## 🔧 Technical Details

### Data Preprocessing Pipeline

1. **Text Cleaning**:
   - Convert to lowercase
   - Remove HTML tags and special characters
   - Remove extra whitespace

2. **Tokenization**: Split text into individual words using NLTK

3. **Stopword Removal**: Remove common English stopwords

4. **Stemming**: Apply Porter Stemmer to reduce words to root forms

5. **Feature Extraction**: TF-IDF vectorization with:
   - Maximum 5000 features
   - Unigrams and bigrams (1-2 n-grams)
   - Sublinear TF scaling

### Model Architecture

- **Algorithm**: Multinomial Naive Bayes
- **Hyperparameters**: Alpha smoothing parameter = 1.0
- **Features**: TF-IDF weighted term frequencies
- **Classes**: 3 classes (negative, neutral, positive)

### Evaluation Metrics

- **Accuracy**: Overall classification accuracy
- **Precision**: True positives / (True positives + False positives)
- **Recall**: True positives / (True positives + False negatives)
- **F1-Score**: Harmonic mean of precision and recall
- **Confusion Matrix**: Detailed breakdown of predictions vs actual labels

## 📱 Streamlit App Features

### Single Review Analysis
- Input any product review text
- Get instant sentiment prediction
- View confidence scores and probability distribution
- Interactive visualizations

### Batch Analysis
- Upload CSV files with multiple reviews
- Process hundreds of reviews at once
- Download results with sentiment predictions
- Summary statistics and visualizations

### Model Information
- Detailed model architecture explanation
- Performance metrics and evaluation results
- Feature importance analysis

### Sample Data Explorer
- Browse the training dataset
- Understand data distribution
- Download sample data for testing

## 🎯 Use Cases

This sentiment analysis system can be applied to:

- **E-commerce**: Analyze customer reviews on platforms like Amazon, Flipkart
- **Social Media**: Monitor brand sentiment on Twitter, Facebook
- **Customer Feedback**: Process survey responses and feedback forms
- **Market Research**: Understand consumer opinions about products/services
- **Content Moderation**: Identify negative or inappropriate content

## 🔮 Future Enhancements

- **Deep Learning Models**: Implement LSTM, BERT, or transformer-based models
- **Multi-language Support**: Extend to analyze reviews in multiple languages
- **Aspect-based Sentiment**: Analyze sentiment for specific product aspects
- **Real-time Processing**: Add streaming data processing capabilities
- **Advanced Visualizations**: Include word clouds, sentiment trends over time
- **Model Comparison**: Compare multiple algorithms (SVM, Random Forest, etc.)

## 📚 Learning Outcomes

This project demonstrates:

- **Text Preprocessing**: Complete NLP pipeline implementation
- **Feature Engineering**: TF-IDF vectorization and n-gram analysis
- **Machine Learning**: Classification model training and evaluation
- **Model Evaluation**: Comprehensive performance assessment
- **Web Development**: Interactive application development with Streamlit
- **Data Visualization**: Creating informative plots and charts
- **Software Engineering**: Modular code structure and documentation

## 🤝 Contributing

Feel free to contribute to this project by:

- Adding new features or improvements
- Fixing bugs or issues
- Enhancing documentation
- Adding more evaluation metrics
- Implementing additional ML algorithms

## 📄 License

This project is open source and available under the MIT License.

## 🙏 Acknowledgments

- **NLTK**: Natural Language Toolkit for text processing
- **scikit-learn**: Machine learning library for model training
- **Streamlit**: Framework for building the web application
- **Plotly**: Interactive visualization library
- **Sample Data**: Synthetic product reviews for demonstration

---

**Happy Analyzing! 🎭📊**
\`\`\`
